package com.sample.flightservice.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sample.flightservice.data.FlightData;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class FlightController {

	@GetMapping(value = "/getFlight")
	public List<FlightData> getFlight(@RequestParam(name = "flightNumber", required = false) String flightNumber,
			@RequestParam(name = "origin", required = false) String origin,
			@RequestParam(name = "destination", required = false) String destination,
			@RequestParam(name = "inputDateStr", required = false) String inputDateStr) {

		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		Date inputDate = null;
		try {
			inputDate = simpleDateFormat.parse(inputDateStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		Calendar inputCalendar = Calendar.getInstance();
		inputCalendar.setTime(inputDate);
		return getFlightData(inputCalendar, flightNumber, origin, destination);

	}

	private FlightData[] loadFlightDatas() {
		ObjectMapper mapper = new ObjectMapper();
		FlightData[] FlightDatas = null;
		try {
			FlightDatas = mapper.readValue(ResourceUtils.getFile("classpath:flight-sample.json"), FlightData[].class);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return FlightDatas;
	}

	private List<FlightData> getFlightData(Calendar inputCalendar, String flightNumber, String origin,
			String destination) {
		List<FlightData> results = new ArrayList<>();
		for (FlightData flightData : loadFlightDatas()) {
			Calendar departureCalendar = Calendar.getInstance();
			departureCalendar.setTime(flightData.getDeparture());
			TimeIgnoringComparator timeIgnoringComparator = new TimeIgnoringComparator();
			if (timeIgnoringComparator.compare(inputCalendar, departureCalendar) == 0) {
				if (flightNumber != null) {
					if (flightData.getFlightNumber().equals(flightNumber)) {
						results.add(flightData);
					}
				}
				if (origin != null && destination != null) {
					if (flightData.getOrigin().equalsIgnoreCase(origin)
							&& flightData.getDestination().equals(destination)) {
						results.add(flightData);
					}
				}
			}
		}
		return results;
	}

}

class TimeIgnoringComparator implements Comparator<Calendar> {
	public int compare(Calendar c1, Calendar c2) {
		if (c1.get(Calendar.YEAR) != c2.get(Calendar.YEAR))
			return c1.get(Calendar.YEAR) - c2.get(Calendar.YEAR);
		if (c1.get(Calendar.MONTH) != c2.get(Calendar.MONTH))
			return c1.get(Calendar.MONTH) - c2.get(Calendar.MONTH);
		return c1.get(Calendar.DAY_OF_MONTH) - c2.get(Calendar.DAY_OF_MONTH);
	}

}
